var calc1 = {}

calc1.add = function(a,b){
    return a+b
}

module.exports=calc1