
var Calc = require('./calc')

var calc = new Calc()

calc.emit('stop')

console.log(Calc.title + '에 stop 이벤트 호출함')