exports.mul = function(a,b){
    return a*b
}